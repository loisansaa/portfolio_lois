import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Code2, Globe, Server } from 'lucide-react';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="flex flex-col items-center">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-[#FFE8D6]">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center">
            <div className="relative w-40 h-40 md:w-48 md:h-48 lg:w-56 lg:h-56 overflow-hidden rounded-2xl neu-border bg-[#B7E4C7] rotate-3">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400&h=400"
                alt="John Doe"
                className="object-cover w-full h-full hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="space-y-4">
              <div className="inline-block bg-[#B7E4C7] -rotate-2 p-4 neu-border">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter">
                  Hi, I'm John Doe
                </h1>
              </div>
              <div className="inline-block bg-[#FF8FA3] rotate-1 p-3 neu-border">
                <h2 className="text-2xl md:text-3xl font-bold">
                  Full Stack Developer
                </h2>
              </div>
              <p className="mx-auto max-w-[700px] text-xl text-black">
                Building beautiful, functional, and scalable web applications with modern technologies.
              </p>
            </div>
            <div className="space-x-4">
              <Button className="neu-button text-lg px-8 py-6" asChild>
                <Link href="/projects">View My Work</Link>
              </Button>
              <Button className="neu-button bg-[#FF8FA3] text-lg px-8 py-6" asChild>
                <Link href="/contact">Get in Touch</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-[#B7E4C7]">
        <div className="container px-4 md:px-6">
          <div className="inline-block bg-white -rotate-1 p-4 neu-border mb-12">
            <h2 className="text-3xl font-bold tracking-tighter">What I Do</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="neu-card p-8 rotate-1">
              <Globe className="w-16 h-16 mb-6 text-[#FF8FA3]" />
              <h3 className="text-2xl font-bold mb-4">Frontend Development</h3>
              <p className="text-lg mb-6">
                Creating responsive and intuitive user interfaces with React, Next.js, and modern CSS.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">React</Badge>
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">Next.js</Badge>
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">Tailwind</Badge>
              </div>
            </Card>
            <Card className="neu-card p-8 -rotate-1">
              <Server className="w-16 h-16 mb-6 text-[#FF8FA3]" />
              <h3 className="text-2xl font-bold mb-4">Backend Development</h3>
              <p className="text-lg mb-6">
                Building scalable APIs and server-side applications with Node.js and modern databases.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">Node.js</Badge>
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">PostgreSQL</Badge>
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">REST APIs</Badge>
              </div>
            </Card>
            <Card className="neu-card p-8 rotate-1">
              <Code2 className="w-16 h-16 mb-6 text-[#FF8FA3]" />
              <h3 className="text-2xl font-bold mb-4">Architecture</h3>
              <p className="text-lg mb-6">
                Designing scalable and maintainable software architectures with best practices.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">System Design</Badge>
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">Cloud</Badge>
                <Badge className="neu-border bg-[#FFE8D6] text-black text-lg">DevOps</Badge>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-[#FFE8D6]">
        <div className="container px-4 md:px-6">
          <div className="flex justify-between items-center mb-12">
            <div className="inline-block bg-white rotate-1 p-4 neu-border">
              <h2 className="text-3xl font-bold tracking-tighter">Featured Projects</h2>
            </div>
            <Button className="neu-button text-lg" asChild>
              <Link href="/projects">
                View All <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="neu-card overflow-hidden rotate-1">
              <div className="aspect-video bg-[#B7E4C7] neu-border m-4" />
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-4">E-commerce Platform</h3>
                <p className="text-lg mb-6">
                  A full-stack e-commerce platform built with Next.js and Supabase.
                </p>
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Badge className="neu-border bg-[#FFE8D6] text-black">Next.js</Badge>
                    <Badge className="neu-border bg-[#FFE8D6] text-black">Supabase</Badge>
                  </div>
                  <Button className="neu-button" size="sm">
                    Learn More
                  </Button>
                </div>
              </div>
            </Card>
            <Card className="neu-card overflow-hidden -rotate-1">
              <div className="aspect-video bg-[#FF8FA3] neu-border m-4" />
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-4">Task Management App</h3>
                <p className="text-lg mb-6">
                  A collaborative task management application with real-time updates.
                </p>
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Badge className="neu-border bg-[#FFE8D6] text-black">React</Badge>
                    <Badge className="neu-border bg-[#FFE8D6] text-black">Node.js</Badge>
                  </div>
                  <Button className="neu-button" size="sm">
                    Learn More
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}