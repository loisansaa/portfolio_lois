import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

export default function AboutPage() {
  const skills = {
    'Frontend': ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Redux'],
    'Backend': ['Node.js', 'Express', 'PostgreSQL', 'MongoDB', 'REST APIs'],
    'DevOps': ['Docker', 'AWS', 'CI/CD', 'Git', 'Linux'],
    'Tools': ['VS Code', 'Figma', 'Postman', 'Jest', 'GitHub'],
  };

  const experiences = [
    {
      company: 'Tech Corp',
      position: 'Senior Software Engineer',
      period: '2021 - Present',
      description: 'Led the development of multiple high-impact projects and mentored junior developers.',
    },
    {
      company: 'StartupX',
      position: 'Full Stack Developer',
      period: '2019 - 2021',
      description: 'Built and maintained various features for the company's main SaaS product.',
    },
    {
      company: 'Digital Agency',
      position: 'Frontend Developer',
      period: '2017 - 2019',
      description: 'Developed responsive web applications for various clients using modern technologies.',
    },
  ];

  return (
    <div className="container py-12">
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-between items-start mb-12">
          <div>
            <h1 className="text-4xl font-bold mb-4">About Me</h1>
            <p className="text-xl text-muted-foreground">
              A passionate software engineer with 6+ years of experience in building web applications.
            </p>
          </div>
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Download CV
          </Button>
        </div>

        <div className="space-y-12">
          <section>
            <h2 className="text-2xl font-bold mb-6">Professional Summary</h2>
            <Card className="p-6">
              <p className="text-muted-foreground leading-relaxed">
                I'm a full-stack developer with a passion for creating elegant solutions to complex problems. 
                With over 6 years of experience in web development, I've worked on various projects ranging 
                from small business websites to large-scale enterprise applications. I'm particularly 
                interested in performance optimization, user experience, and building scalable architectures.
              </p>
            </Card>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-6">Skills</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {Object.entries(skills).map(([category, items]) => (
                <Card key={category} className="p-6">
                  <h3 className="font-bold mb-4">{category}</h3>
                  <div className="flex flex-wrap gap-2">
                    {items.map((skill) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-6">Experience</h2>
            <div className="space-y-4">
              {experiences.map((exp, index) => (
                <Card key={index} className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-lg">{exp.position}</h3>
                      <p className="text-muted-foreground">{exp.company}</p>
                    </div>
                    <Badge variant="outline">{exp.period}</Badge>
                  </div>
                  <p className="text-muted-foreground">
                    {exp.description}
                  </p>
                </Card>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}