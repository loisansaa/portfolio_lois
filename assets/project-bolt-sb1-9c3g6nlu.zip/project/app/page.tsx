import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Code2, Globe, Server } from 'lucide-react';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="flex flex-col items-center">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center">
            <div className="relative w-32 h-32 md:w-40 md:h-40 lg:w-48 lg:h-48 overflow-hidden rounded-full border-4 border-primary mb-4">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400&h=400"
                alt="John Doe"
                className="object-cover w-full h-full transition-transform duration-300 hover:scale-110"
              />
            </div>
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Hi, I'm John Doe
                <br />
                Full Stack Developer
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Building beautiful, functional, and scalable web applications with modern technologies.
              </p>
            </div>
            <div className="space-x-4">
              <Button asChild>
                <Link href="/projects">View My Work</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/contact">Get in Touch</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tighter text-center mb-12">What I Do</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="p-6">
              <Globe className="w-12 h-12 mb-4" />
              <h3 className="text-xl font-bold mb-2">Frontend Development</h3>
              <p className="text-muted-foreground mb-4">
                Creating responsive and intuitive user interfaces with React, Next.js, and modern CSS.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge>React</Badge>
                <Badge>Next.js</Badge>
                <Badge>Tailwind</Badge>
              </div>
            </Card>
            <Card className="p-6">
              <Server className="w-12 h-12 mb-4" />
              <h3 className="text-xl font-bold mb-2">Backend Development</h3>
              <p className="text-muted-foreground mb-4">
                Building scalable APIs and server-side applications with Node.js and modern databases.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge>Node.js</Badge>
                <Badge>PostgreSQL</Badge>
                <Badge>REST APIs</Badge>
              </div>
            </Card>
            <Card className="p-6">
              <Code2 className="w-12 h-12 mb-4" />
              <h3 className="text-xl font-bold mb-2">Architecture</h3>
              <p className="text-muted-foreground mb-4">
                Designing scalable and maintainable software architectures with best practices.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge>System Design</Badge>
                <Badge>Cloud</Badge>
                <Badge>DevOps</Badge>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter">Featured Projects</h2>
            <Button variant="ghost" asChild>
              <Link href="/projects">
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="overflow-hidden">
              <div className="aspect-video bg-muted" />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">E-commerce Platform</h3>
                <p className="text-muted-foreground mb-4">
                  A full-stack e-commerce platform built with Next.js and Supabase.
                </p>
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Badge>Next.js</Badge>
                    <Badge>Supabase</Badge>
                  </div>
                  <Button variant="ghost" size="sm">
                    Learn More
                  </Button>
                </div>
              </div>
            </Card>
            <Card className="overflow-hidden">
              <div className="aspect-video bg-muted" />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Task Management App</h3>
                <p className="text-muted-foreground mb-4">
                  A collaborative task management application with real-time updates.
                </p>
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Badge>React</Badge>
                    <Badge>Node.js</Badge>
                  </div>
                  <Button variant="ghost" size="sm">
                    Learn More
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}