import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Github, Linkedin, Mail, Server, Database, Code2, Terminal, ExternalLink, ChevronRight } from 'lucide-react';

function App() {
  const [activeProject, setActiveProject] = useState<number | null>(null);
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Section with Animation */}
      <motion.header 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="bg-gradient-to-r from-slate-800 to-slate-900 text-white py-20"
      >
        <div className="container mx-auto px-6">
          <div className="max-w-3xl">
            <motion.h1 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-4xl md:text-5xl font-bold mb-4"
            >
              Backend Developer
            </motion.h1>
            <motion.p 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-xl text-slate-300 mb-8"
            >
              Building robust and scalable server-side solutions
            </motion.p>
            <motion.div 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="flex space-x-4"
            >
              <motion.a 
                href="#contact"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg font-semibold transition flex items-center space-x-2"
              >
                <span>Contact Me</span>
                <ChevronRight className="w-4 h-4" />
              </motion.a>
              <motion.a 
                href="#projects"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-slate-700 hover:bg-slate-600 px-6 py-3 rounded-lg font-semibold transition"
              >
                View Projects
              </motion.a>
            </motion.div>
          </div>
        </div>
      </motion.header>

      {/* About Section with Scroll Animation */}
      <section id="about" className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            ref={ref}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            variants={staggerContainer}
            className="grid md:grid-cols-2 gap-12 items-center"
          >
            <motion.div variants={fadeInUp}>
              <motion.img 
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
                src="https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                alt="Developer workspace"
                className="rounded-lg shadow-lg"
              />
            </motion.div>
            <motion.div variants={fadeInUp}>
              <h2 className="text-3xl font-bold mb-8">About Me</h2>
              <p className="text-lg text-slate-600 mb-6">
                I'm a passionate backend developer with a strong foundation in server-side technologies.
                My focus is on building efficient, scalable, and maintainable systems that power modern web applications.
              </p>
              <p className="text-lg text-slate-600">
                With experience in database design, API development, and system architecture,
                I strive to create robust solutions that meet business needs while following best practices.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Skills Section with Hover Effects */}
      <section id="skills" className="py-20 bg-slate-100">
        <div className="container mx-auto px-6">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-12"
          >
            Technical Skills
          </motion.h2>
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {[
              { icon: Server, title: "Backend Development", skills: "Node.js, Express, REST APIs" },
              { icon: Database, title: "Databases", skills: "PostgreSQL, MongoDB, Redis" },
              { icon: Code2, title: "Languages", skills: "JavaScript, Python, SQL" },
              { icon: Terminal, title: "Tools", skills: "Git, Docker, AWS" }
            ].map((skill, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                whileHover={{ y: -5, scale: 1.02 }}
                className="bg-white p-6 rounded-lg shadow-md transition-all duration-300"
              >
                <skill.icon className="w-12 h-12 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{skill.title}</h3>
                <p className="text-slate-600">{skill.skills}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Projects Section with Interactive Cards */}
      <section id="projects" className="py-20">
        <div className="container mx-auto px-6">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-12"
          >
            Featured Projects
          </motion.h2>
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {[
              {
                title: "E-commerce API",
                image: "https://images.unsplash.com/photo-1557853197-aefb550b6fdc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
                description: "RESTful API for an e-commerce platform with authentication, product management, and order processing.",
                tech: ["Node.js", "Express", "MongoDB"]
              },
              {
                title: "Task Management System",
                image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
                description: "Backend system for managing tasks, teams, and project workflows with real-time updates.",
                tech: ["Python", "FastAPI", "PostgreSQL"]
              },
              {
                title: "Data Analytics Pipeline",
                image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80",
                description: "Automated data processing pipeline for analyzing and visualizing large datasets.",
                tech: ["Python", "AWS", "Redis"]
              }
            ].map((project, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="bg-white rounded-lg shadow-md overflow-hidden group"
                whileHover={{ y: -5 }}
                onClick={() => setActiveProject(activeProject === index ? null : index)}
              >
                <div className="relative overflow-hidden">
                  <motion.img 
                    src={project.image}
                    alt={project.title}
                    className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <ExternalLink className="w-8 h-8 text-white" />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-slate-600 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech, techIndex) => (
                      <span key={techIndex} className="px-3 py-1 bg-slate-100 rounded-full text-sm">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Contact Section with Interactive Links */}
      <section id="contact" className="py-20 bg-slate-100">
        <div className="container mx-auto px-6">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-12"
          >
            Get In Touch
          </motion.h2>
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="max-w-2xl mx-auto"
          >
            <div className="flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-8">
              {[
                { icon: Mail, text: "your.email@example.com", href: "mailto:your.email@example.com" },
                { icon: Github, text: "GitHub", href: "https://github.com/yourusername" },
                { icon: Linkedin, text: "LinkedIn", href: "https://linkedin.com/in/yourusername" }
              ].map((contact, index) => (
                <motion.a
                  key={index}
                  variants={fadeInUp}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  href={contact.href}
                  target={contact.href.startsWith('http') ? "_blank" : undefined}
                  rel={contact.href.startsWith('http') ? "noopener noreferrer" : undefined}
                  className="flex items-center space-x-2 text-slate-700 hover:text-blue-600 transition"
                >
                  <contact.icon className="w-6 h-6" />
                  <span>{contact.text}</span>
                </motion.a>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer with Hover Effect */}
      <footer className="bg-slate-900 text-white py-8">
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="container mx-auto px-6 text-center"
        >
          <p>© 2024 Your Name. All rights reserved.</p>
        </motion.div>
      </footer>
    </div>
  );
}

export default App;